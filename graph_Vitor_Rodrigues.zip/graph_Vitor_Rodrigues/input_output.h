//
// Created by vitor on 30/08/23.
//

#ifndef UNTITLED62_INPUT_OUTPUT_H
#define UNTITLED62_INPUT_OUTPUT_H

void verificaNumero(char *controle, void *ptr);
void menu(int quantidade, char *frase, ...);
char *digText(FILE *f, char parar);
#endif //UNTITLED62_INPUT_OUTPUT_H
